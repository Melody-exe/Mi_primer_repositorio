from setuptools import setup
setup(
    name='mipaquete', #no ti3ne porq ser el mismo que paquete
    version='1.0', #la coma es IMPORTANTE
    description='mi primer paquete redis',
    author='Franco',
    packages=['paquete'],


)