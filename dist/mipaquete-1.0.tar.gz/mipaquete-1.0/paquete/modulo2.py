def funcion_modulo2():
    print("hola, soy un módulo en el paquete modulo2")