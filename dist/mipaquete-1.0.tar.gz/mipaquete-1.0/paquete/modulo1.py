def funcionPaquete():
    print("hola estoy en mi paquete")